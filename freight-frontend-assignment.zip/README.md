# Freight Frontend Assignment

## Task 1
Professional logistics website with Home and About pages.

## Task 2
Custom UI Home page using the same business content.

## Tech Stack
- HTML5
- CSS3
- Tailwind CSS

## Features
- Fully responsive
- Clean, readable code
